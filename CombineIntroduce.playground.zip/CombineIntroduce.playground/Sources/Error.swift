import Foundation

public enum MyError: Error {
    case someError
    case none
}
